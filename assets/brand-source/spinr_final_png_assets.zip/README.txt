Spinr final PNG assets

Source:
- Built from the exact uploaded wordmark and S-mark images.
- No design changes were made; files were cleaned/cropped and exported as separate high-resolution PNG assets.

Included:
- Wordmark: black transparent, white transparent, black-on-white, white-on-black.
- S mark / favicon: black transparent, white transparent, black-on-white, white-on-black.
- Favicon PNG sizes: 1024, 512, 256, 128, 64, 32.
- Horizontal lockup: S mark + wordmark in black/white/background versions.

Note:
These are PNG files reconstructed from uploaded raster screenshots. They are high resolution, but not true vector originals.
For final brand production, a designer should trace/outline this exact logo in Figma or Illustrator.
