SPINR BRAND ASSET DRAFTS

Primary brand color from the card:
HEX: #D7FC47
RGB: 215, 252, 71
Approx CMYK: 15, 0, 72, 0

Files included:
- Icon / favicon PNGs: 1024, 512, 256, 128, 64, 32 px
- Wordmark PNGs: black on white, white on black, transparent black, transparent white
- Horizontal lockups: color on white, color on black, transparent, black/white versions
- SVG approximations for the icon and mark

Important note:
These are separated working assets generated from the selected visual direction. The wordmark is reconstructed from the concept image, so it is suitable for web mockups and designer handoff, but a designer should recreate the final wordmark as vector outlines before production launch.
